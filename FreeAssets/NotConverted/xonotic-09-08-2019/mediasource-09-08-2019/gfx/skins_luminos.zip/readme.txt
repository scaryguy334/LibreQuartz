==========================
Luminos - Xonotic Skin(s)
==========================

Released : 2010
Author   : Severin "sev" Meyer
EMail    : sev.ch(at)web.de

Programs used: Inkscape 0.48, Gimp 2.6.8, Blender 2.49a, ImageMagick 6.5.4-8

==========================
./create scripts (Linux)
==========================

The ./create shell scripts batch-export, render and
convert the final images from various sourcefiles.

They use Inkscape, Gimp, Blender and ImageMagick, and require the provided
Gimp scripts (gimp_files/*.scm) to be present in ~/.gimp*/scripts/.

==========================
Foreign Sourcefiles
==========================

All foreign images and Blender materials I used for the
HUD skin have been released into the Public Domain.

For some of the notify icons, I used the following Blender materials from the
Blender Open Material Repository, found at http://www.blender-materials.org:
alien_egg.blend by sypher7
hard_lava.blend by madnux
ocean_water.blend by Paratron

The original photography of the tent (notify_camping) can be found here:
http://commons.wikimedia.org/wiki/File:NEMO_Moki.jpg

The original photography of the trout (notify_melee) can be found here:
http://commons.wikimedia.org/wiki/File:Brown_Trout_19_10_08.JPG

==========================
GNU General Public License
==========================

I release the files, that I created for this project, under the terms of the
GNU General Public License as published by the Free Software Foundation, either
version 2 of the License, or any later version. <http://www.gnu.org/licenses/>

All the files that are part of this project are distributed in the hope
that they will be useful, but WITHOUT ANY WARRANTY; without even the
implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
